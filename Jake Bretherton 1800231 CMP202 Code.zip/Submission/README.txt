Jake Bretherton 1800231
Submission for CMP202 project

The channel class is a templated class so has a tpp instead of a cpp file, if you're having trouble finding it

A repo of the project can be found here https://github.com/ProbablyJake/CMP202Project

